/**
 * DraggableClass Component
 * -------------------------------------
 * This component is similar to ClassEntity, but with improved styling and labels.
 * It uses React DnD to allow dragging and dropping within the diagram.
 * The parent (CanvasArea) listens to onDragEnd to update positions in Redux.
 */

import React from "react";
import { useDrag } from "react-dnd";
import {
  Box,
  Typography,
  IconButton,
  Card,
  CardHeader,
  CardContent,
  Tooltip,
  useTheme,
  Divider,
} from "@mui/material";

import EditIcon from "@mui/icons-material/Edit";
import DeleteIcon from "@mui/icons-material/Delete";

const DraggableClass = ({
  id,
  name,
  x,
  y,
  attributes,
  methods,
  deleteClass,
  onEdit,
  onDragEnd,
}) => {
  const theme = useTheme();

  // Set up drag logic using React DnD
  const [{ isDragging }, drag] = useDrag(
    () => ({
      type: "CLASS",
      item: { id, x, y },
      collect: (monitor) => ({
        isDragging: monitor.isDragging(),
      }),
      end: (item, monitor) => {
        const delta = monitor.getDifferenceFromInitialOffset();
        if (delta) {
          onDragEnd(delta);
        }
      },
    }),
    [id, x, y, onDragEnd]
  );

  // Slightly reduce opacity if dragging
  const opacity = isDragging ? 0.7 : 1;

  return (
    <Tooltip title="Cliquez pour modifier la classe">
      <Box
        ref={drag}
        sx={{
          position: 'absolute',
          left: x,
          top: y,
          width: 200,
          bgcolor: 'background.paper',
          borderRadius: 1,
          boxShadow: 2,
          cursor: 'move',
          userSelect: 'none',
          zIndex: isDragging ? 1000 : 1,
        }}
      >
        <CardHeader
          title={
            <Typography variant="h6" noWrap>
              {name}
            </Typography>
          }
          action={
            <Box>
              <Tooltip title="Modifier Classe">
                <IconButton size="small" onClick={onEdit}>
                  <EditIcon fontSize="small" />
                </IconButton>
              </Tooltip>
              <Tooltip title="Supprimer Classe">
                <IconButton size="small" onClick={() => deleteClass(id)}>
                  <DeleteIcon fontSize="small" />
                </IconButton>
              </Tooltip>
            </Box>
          }
          sx={{
            paddingBottom: 0,
            "& .MuiCardHeader-content": {
              padding: 0,
            },
          }}
        />
        <Divider />

        <CardContent sx={{ paddingTop: 1, paddingBottom: 1 }}>
          <Typography variant="subtitle2" color="textSecondary">
            Attributs
          </Typography>
          {attributes && attributes.length > 0 ? (
            attributes.map((attr, index) => (
              <Typography
                key={index}
                variant="body2"
                sx={{
                  display: "flex",
                  justifyContent: "space-between",
                  mt: 0.5,
                }}
              >
                <Box>
                  {attr.access} {attr.name}
                </Box>
                <Box color="textSecondary">{attr.type}</Box>
              </Typography>
            ))
          ) : (
            <Typography variant="body2" color="textSecondary">
              Aucun attribut
            </Typography>
          )}
        </CardContent>
        <Divider />

        <CardContent sx={{ paddingTop: 1, paddingBottom: 1 }}>
          <Typography variant="subtitle2" color="textSecondary">
            Méthodes
          </Typography>
          {methods && methods.length > 0 ? (
            methods.map((method, index) => (
              <Typography
                key={index}
                variant="body2"
                sx={{
                  display: "flex",
                  justifyContent: "space-between",
                  mt: 0.5,
                }}
              >
                <Box>
                  {method.access} {method.name}()
                </Box>
                <Box color="textSecondary">{method.returnType}</Box>
              </Typography>
            ))
          ) : (
            <Typography variant="body2" color="textSecondary">
              Aucune méthode
            </Typography>
          )}
        </CardContent>
      </Box>
    </Tooltip>
  );
};

export default DraggableClass;
