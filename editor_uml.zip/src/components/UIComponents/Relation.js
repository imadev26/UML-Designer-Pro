/**
 * Relation Component
 * -------------------------------------
 * Draws a UML-style line from source class to target class.
 */

import React from "react";
import PropTypes from "prop-types";

const Relation = ({
  source,
  target,
  type,
  sourceCardinality,
  targetCardinality,
  classWidth = 200,
  classHeight = 100,
}) => {
  if (!source || !target) return null;

  // Calculate centers of the classes
  const sourceCenter = {
    x: source.x + classWidth / 2,
    y: source.y + classHeight / 2,
  };

  const targetCenter = {
    x: target.x + classWidth / 2,
    y: target.y + classHeight / 2,
  };

  // Calculate intersection points with class borders
  const calculateIntersection = (rect, isSource) => {
    const halfWidth = classWidth / 2;
    const halfHeight = classHeight / 2;
    const center = isSource ? sourceCenter : targetCenter;
    const otherCenter = isSource ? targetCenter : sourceCenter;
    
    // Calculate angle to target/source
    const dx = otherCenter.x - center.x;
    const dy = otherCenter.y - center.y;
    const angle = Math.atan2(dy, dx);
    
    // Add offset to prevent crossing borders
    const offset = 10; // Offset from class border
    
    let x, y;
    
    if (Math.abs(Math.cos(angle)) * halfHeight > Math.abs(Math.sin(angle)) * halfWidth) {
      // Intersect with left/right edge
      x = center.x + (halfWidth * Math.sign(Math.cos(angle)));
      y = center.y + Math.tan(angle) * (halfWidth * Math.sign(Math.cos(angle)));
      x += offset * Math.sign(Math.cos(angle));
    } else {
      // Intersect with top/bottom edge
      y = center.y + (halfHeight * Math.sign(Math.sin(angle)));
      x = center.x + ((y - center.y) / Math.tan(angle));
      y += offset * Math.sign(Math.sin(angle));
    }

    return { x, y };
  };

  const start = calculateIntersection(source, true);
  const end = calculateIntersection(target, false);

  // Generate unique marker IDs
  const markerId = `marker-${source.x}-${source.y}-${target.x}-${target.y}`;

  // Determine if cardinalities should be shown based on relation type
  const showCardinalities = ['association', 'aggregation', 'composition'].includes(type);

  // Calculate cardinality positions with offset
  const cardinalityOffset = 25;
  const dx = end.x - start.x;
  const dy = end.y - start.y;
  const angle = Math.atan2(dy, dx);

  const sourceCardPos = {
    x: start.x + (Math.cos(angle) * cardinalityOffset),
    y: start.y + (Math.sin(angle) * cardinalityOffset),
  };

  const targetCardPos = {
    x: end.x - (Math.cos(angle) * cardinalityOffset),
    y: end.y - (Math.sin(angle) * cardinalityOffset),
  };

  return (
    <svg
      style={{
        position: "absolute",
        top: 0,
        left: 0,
        width: "100%",
        height: "100%",
        pointerEvents: "none",
        overflow: "visible",
        zIndex: 1000,
      }}
    >
      <defs>
        {/* Inheritance/Implementation arrow */}
        <marker
          id={`${markerId}-triangle`}
          viewBox="0 0 10 10"
          refX="10"
          refY="5"
          markerWidth="10"
          markerHeight="10"
          orient="auto"
        >
          <path d="M 0 0 L 10 5 L 0 10 z" fill="white" stroke="black" />
        </marker>

        {/* Aggregation diamond */}
        <marker
          id={`${markerId}-diamond-hollow`}
          viewBox="0 0 12 12"
          refX="6"
          refY="6"
          markerWidth="12"
          markerHeight="12"
          orient="auto"
        >
          <path d="M 0 6 L 6 0 L 12 6 L 6 12 z" fill="white" stroke="black" />
        </marker>

        {/* Composition diamond */}
        <marker
          id={`${markerId}-diamond-filled`}
          viewBox="0 0 12 12"
          refX="6"
          refY="6"
          markerWidth="12"
          markerHeight="12"
          orient="auto"
        >
          <path d="M 0 6 L 6 0 L 12 6 L 6 12 z" fill="black" stroke="black" />
        </marker>

        {/* Dependency arrow */}
        <marker
          id={`${markerId}-dependency`}
          viewBox="0 0 10 10"
          refX="10"
          refY="5"
          markerWidth="10"
          markerHeight="10"
          orient="auto"
        >
          <path d="M 0 0 L 10 5 L 0 10" fill="none" stroke="black" />
        </marker>
      </defs>

      {/* Main line */}
      <line
        x1={start.x}
        y1={start.y}
        x2={end.x}
        y2={end.y}
        stroke="black"
        strokeWidth="2"
        markerStart={
          type === "aggregation"
            ? `url(#${markerId}-diamond-hollow)`
            : type === "composition"
            ? `url(#${markerId}-diamond-filled)`
            : null
        }
        markerEnd={
          type === "generalization" || type === "implementation"
            ? `url(#${markerId}-triangle)`
            : type === "dependency"
            ? `url(#${markerId}-dependency)`
            : null
        }
        strokeDasharray={
          type === "dependency" || type === "implementation" 
            ? "4,4" 
            : "none"
        }
      />

      {/* Cardinalities - only show for association types */}
      {showCardinalities && sourceCardinality && (
        <g transform={`translate(${sourceCardPos.x},${sourceCardPos.y})`}>
          <rect
            x="-15"
            y="-12"
            width="30"
            height="20"
            fill="white"
            stroke="none"
          />
          <text
            textAnchor="middle"
            dominantBaseline="middle"
            fontSize="12"
          >
            {sourceCardinality}
          </text>
        </g>
      )}

      {showCardinalities && targetCardinality && (
        <g transform={`translate(${targetCardPos.x},${targetCardPos.y})`}>
          <rect
            x="-15"
            y="-12"
            width="30"
            height="20"
            fill="white"
            stroke="none"
          />
          <text
            textAnchor="middle"
            dominantBaseline="middle"
            fontSize="12"
          >
            {targetCardinality}
          </text>
        </g>
      )}
    </svg>
  );
};

Relation.propTypes = {
  source: PropTypes.shape({
    x: PropTypes.number,
    y: PropTypes.number,
  }).isRequired,
  target: PropTypes.shape({
    x: PropTypes.number,
    y: PropTypes.number,
  }).isRequired,
  type: PropTypes.oneOf([
    "association",
    "aggregation",
    "composition",
    "generalization",
    "implementation",
    "dependency",
  ]).isRequired,
  sourceCardinality: PropTypes.string,
  targetCardinality: PropTypes.string,
  classWidth: PropTypes.number,
  classHeight: PropTypes.number,
};

export default Relation;
